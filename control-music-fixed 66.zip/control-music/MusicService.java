package com.controlmusic.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

/** Foreground service: mantém o processo vivo enquanto a música toca em segundo plano. */
public class MusicService extends Service {
  private static final String CH = "playback";
  private PowerManager.WakeLock wl;

  @Override
  public IBinder onBind(Intent i) { return null; }

  @Override
  public int onStartCommand(Intent i, int flags, int startId) {
    String title = (i != null) ? i.getStringExtra("title") : null;
    if (title == null || title.isEmpty()) title = "Control Music";

    NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
    if (Build.VERSION.SDK_INT >= 26) {
      nm.createNotificationChannel(new NotificationChannel(CH, "Reprodução", NotificationManager.IMPORTANCE_LOW));
    }
    Intent open = new Intent(this, MainActivity.class);
    open.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
    PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

    Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CH) : new Notification.Builder(this);
    b.setContentTitle(title).setContentText("Control Music · tocando")
      .setSmallIcon(android.R.drawable.ic_media_play)
      .setContentIntent(pi).setOngoing(true);
    Notification n = b.build();

    if (Build.VERSION.SDK_INT >= 29) {
      startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
    } else {
      startForeground(1, n);
    }

    if (wl == null) {
      PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
      wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "controlmusic:play");
      wl.setReferenceCounted(false);
      wl.acquire();
    }
    return START_STICKY;
  }

  @Override
  public void onDestroy() {
    if (wl != null && wl.isHeld()) wl.release();
    wl = null;
    super.onDestroy();
  }
}
