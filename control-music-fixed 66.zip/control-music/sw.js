const CACHE = 'control-music-v1', SHARED = 'shared-files';
const SHELL = ['./', './index.html', './manifest.json', './icon-192.png', './icon-512.png'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).catch(() => {}).then(() => self.skipWaiting()));
});
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));

self.addEventListener('fetch', e => {
  const req = e.request, u = new URL(req.url);

  // Recebe arquivos compartilhados pelo gerenciador de arquivos
  if (req.method === 'POST' && u.pathname.endsWith('/share-target')) {
    e.respondWith((async () => {
      const fd = await req.formData();
      const cache = await caches.open(SHARED);
      let i = 0;
      for (const f of fd.getAll('media')) {
        if (!(f instanceof File)) continue;
        await cache.put(
          new URL('./shared/' + Date.now() + '-' + (i++), self.registration.scope).href,
          new Response(f, { headers: { 'Content-Type': f.type || 'application/octet-stream', 'X-Name': encodeURIComponent(f.name) } })
        );
      }
      return Response.redirect(new URL('./?shared=1', self.registration.scope).href, 303);
    })());
    return;
  }

  if (req.method !== 'GET' || u.origin !== location.origin) return;
  e.respondWith(
    fetch(req).then(r => { const c = r.clone(); caches.open(CACHE).then(x => x.put(req, c)); return r; })
      .catch(() => caches.match(req).then(r => r || caches.match('./index.html')))
  );
});
